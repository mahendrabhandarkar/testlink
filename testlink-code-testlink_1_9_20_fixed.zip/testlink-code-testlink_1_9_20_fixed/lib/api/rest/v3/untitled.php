      $buildProp = array('tplan_id' => 'tplan_id',
                         'release_date' => 'release_date',
                         'releasedate' => 'release_date',
                         'active' => 'is_active',
                         'is_active' => 'is_active',
                         'notes' => 'notes',
                         'commit_id' => 'commit_id', 
                         'tag' => 'tag', 
                         'branch' => 'branch', 
                         'is_open' => 'is_open',
                         'release_candidate' =>
                            'release_candidate',
                         'copytestersfrombuild' =>
                            'copytestersfrombuild',      
                         'copy_testers_from_build' => 
                            'copytestersfrombuild');


     $buildProp = array('name' => 'name',
                         'tplan_id' => 'tplan_id',
                         'release_date' => 'release_date',
                         'releasedate' => 'release_date',
                         'active' => 'is_active',
                         'is_active' => 'is_active',
                         'notes' => 'notes',
                         'commit_id' => 'commit_id', 
                         'tag' => 'tag', 'branch' => 'branch', 
                         'release_candidate' =>'release_candidate',
                         'is_open' => 'is_open',
                         'copytestersfrombuild' => 
                              'copytestersfrombuild',                         
                         'copy_testers_from_build' => 
                              'copytestersfrombuild');
